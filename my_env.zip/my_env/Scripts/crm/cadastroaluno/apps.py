from django.apps import AppConfig


class CadastroalunoConfig(AppConfig):
    name = 'cadastroaluno'
